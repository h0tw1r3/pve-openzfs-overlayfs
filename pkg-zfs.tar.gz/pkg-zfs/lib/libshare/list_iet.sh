#!/bin/sh

cat /proc/net/iet/volume
